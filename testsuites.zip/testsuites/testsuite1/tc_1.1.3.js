/* 
 Author: Arko
 Description:    This is a casperjs automated test script for showing that when the user is logging-in for the first time, execute the successful 
 login by going to the github, allow the user access and load the main page of Rcloud
 */

//Begin Tests

casper.test.begin("Rcloud Authentication Tests", 3, function suite(test) {

    var x= require('casper').selectXPath;
    var github_username = casper.cli.options.username;
    var github_password = casper.cli.options.password;
    var rcloud_url = casper.cli.options.url;

    casper.start(rcloud_url, function() {
    });

    casper.wait(10000);

    casper.viewport(1024,768).then(function() {
        if (casper.getTitle().match(/GitHub/))
        {

            casper.viewport(1024,768).then(function() {
                test.assertTitleMatch(/GitHub/, "Github page has been loaded");
                console.log("Login into GitHub with supplied username and password");
                this.sendKeys('#login_field', github_username);
                this.sendKeys('#password', github_password);
                this.click({type: 'css', path: '#login > form > div.auth-form-body > input.button'});
            });

            casper.viewport(1024,768).then(function() {
                if (this.getTitle().match(/GitHub/))
                {

                    this.click({type: 'css', path: 'html body.logged_in div.wrapper div.site div#site-container.context-loader-container div.setup-wrapper div.setup-main form p button.button'});
                    console.log("Github Authorization completed");

                }
                else

                {
                    casper.viewport(1024,768).then(function() {
                        //test.assertTitleMatch(/RCloud/, 'Rcloud Home page loaded');
                        this.echo("The page title: " + this.getTitle());
                        console.log("Rcloud Home page loaded");
                    });
                }
            });

        }
        else
        {
            casper.viewport(1024,768).then(function() {
                test.assertTitleMatch(/RCloud/, 'Rcloud Home page already loaded');
            });
        }
    });



    casper.viewport(1024,768).then(function() {
        this.wait(9000);
        console.log("validating that the Main page has got loaded properly by detecting if some of its elements are visible. Here we are checking for Shareable Link and Logout options");
        this.test.assertExists(
            {type: 'xpath', path: '/html/body/div[2]/div/div[2]/ul/li/span/a' },
            'the element Shareable Link exists'
        );
        this.test.assertExists(
            {type: 'xpath', path: '/html/body/div[2]/div/div[2]/ul[2]/li[3]/a' },
            'Logout option exists'
        );

    });



    casper.run(function() {
        test.done();
    });
});
