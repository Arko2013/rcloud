/* 
    Author: Arko
    Description:    This is a casperjs automated test script for showning that on clicking the GitHub Logout button present in 
                    "goodbye.R" page, the user gets a notification if he/she wants to log out of GitHub,confirming which,the user
                     gets logged out from GitHub and Sign-In page of github.com opens
                    
    
*/

//Begin Tests

casper.test.begin("Logout of Github", 6, function suite(test) {
	    
    var x= require('casper').selectXPath;
    var github_username = casper.cli.options.username;
    var github_password = casper.cli.options.password;
    var rcloud_url = casper.cli.options.url;
    
    casper.start(rcloud_url, function() {  
    });
	
	casper.wait(10000);
	
	casper.viewport(1024,768).then(function() {
    if (casper.getTitle().match(/GitHub/))
	{
	
    casper.viewport(1024,768).then(function() {
       test.assertTitleMatch(/GitHub/, "Github page has been loaded"); 
       console.log("Login into GitHub with supplied username and password");
        this.sendKeys('#login_field', github_username);
        this.sendKeys('#password', github_password); 
        this.click({type: 'css', path: '#login > form > div.auth-form-body > input.button'});
    });
    
    casper.viewport(1024,768).then(function() {
        if (this.getTitle().match(/GitHub/)) 
        {
        
	   this.click({type: 'css', path: 'html body.logged_in div.wrapper div.site div#site-container.context-loader-container div.setup-wrapper div.setup-main form p button.button'}); 
	 	console.log("Github Authorization completed");
            
        }
        else
            
        {
            casper.viewport(1024,768).then(function() {
               //test.assertTitleMatch(/RCloud/, 'Rcloud Home page loaded');
			   this.echo("The page title: " + this.getTitle());
			   console.log("Rcloud Home page loaded");
            });
        }
	});
	
	}
	else
	{
           casper.viewport(1024,768).then(function() {
               test.assertTitleMatch(/RCloud/, 'Rcloud Home page already loaded');
            });
    }
});
    
    
    
    casper.viewport(1024,768).then(function() {
		this.wait(9000);
		console.log("validating that the Main page has got loaded properly by detecting if some of its elements are visible. Here we are checking for Shareable Link and Logout options");
		this.test.assertExists(
			{type: 'xpath', path: '/html/body/div[2]/div/div[2]/ul/li/span/a' },
			'the element Shareable Link exists'
			);
		this.test.assertExists(
			{type: 'xpath', path: '/html/body/div[2]/div/div[2]/ul[2]/li[3]/a' },
			'Logout option exists'
			);
			
	});
	
	
	casper.viewport(1366,768).thenClick(x('/html/body/div[2]/div/div[2]/ul[2]/li[3]/a'),function(){
		  console.log('Logging out of RCloud');
		  this.wait(7000);
	});
	  
	casper.viewport(1366,768).then(function() {
		this.echo("The url after logging out of RCloud : " + this.getCurrentUrl());
		this.test.assertTextExists(
        'Log back in',"Log Back In option exists"
		);
		
	});
	
	casper.viewport(1366,768).thenClick(x('/html/body/div[2]/p[2]/a[2]'),function(){
		  console.log('Logging out of Github');
		  this.wait(10000);
	  });
	  
	casper.viewport(1366,768).then(function(){
		  this.echo("The url where the user can confirm logging out from Github : " + this.getCurrentUrl());
		  this.test.assertTextExists(
        'Are you sure you want to sign out?',"Option to Sign Out of GitHub exists"
		);
	});
	
	casper.viewport(1366,768).thenClick(x('/html/body/div/div[3]/div/div/form/div[3]/input'),function(){
		console.log('logged out of Github');
		this.wait(7000);
		this.echo("The url after logging out of Github : " + this.getCurrentUrl());
		this.test.assertTextExists(
        'GitHub',"Confirmed that successfully logged out of Github"
		);
		
	});
	
	   
    casper.run(function() {
        test.done();
    });
});
